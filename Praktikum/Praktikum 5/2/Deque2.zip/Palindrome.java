
public class Palindrome<T> {
    //Method untuk mengecek apakah Deque dq merupakan palindrome
    //Deque dq merupakan palindrome jika elemen-elemen pada Deque dq dapat dibaca sama dari depan dan belakang
    public boolean isPalindrome(Deque<T> dq){
        boolean isPal = true;
        while(!dq.isEmpty()){
            try {
                T first = dq.popFront();
                if(!dq.isEmpty()){
                    T last = dq.popBack();
                    if(first!=last){
                        isPal = false;
                    }
                }
                
            } catch (Exception e) {
                // TODO: handle exception
            }
            
        }
        return isPal;

    }
}
